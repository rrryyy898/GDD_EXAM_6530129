using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Public variables visible in Inspector
    public float speed = 5.0f;
    public float turnSpeed = 45.0f;

    // Private variables for input
    public float horizontalInput;
    public float forwardInput;




    // Update is called once per frame
    void Update()
    {
        // Get player input
        horizontalInput = Input.GetAxis("Horizontal");
        forwardInput = Input.GetAxis("Vertical");

        // Rotate the vehicle left/right
        transform.Rotate(Vector3.up, horizontalInput * turnSpeed * Time.deltaTime);

        // Move the vehicle forward/backward
        transform.Translate(Vector3.forward * Time.deltaTime * speed * forwardInput);




    }
}
