using UnityEngine;

public class PauseMenu : MonoBehaviour
{
    [SerializeField] GameObject pauseUI;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            bool willPause = !pauseUI.activeSelf;
            pauseUI.SetActive(willPause);
            Time.timeScale = willPause ? 0f : 1f;
        }
    }

    public void Resume()
    {
        pauseUI.SetActive(false);
        Time.timeScale = 1f;
    }
}
