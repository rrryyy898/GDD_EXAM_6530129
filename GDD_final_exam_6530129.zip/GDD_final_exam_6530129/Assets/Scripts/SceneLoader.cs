using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{
    public void LoadMainMenu() { Time.timeScale = 1f; SceneManager.LoadScene("MainMenu"); }
    public void LoadDriving() { Time.timeScale = 1f; SceneManager.LoadScene("DrivingGame"); }
    public void LoadFlying() { Time.timeScale = 1f; SceneManager.LoadScene("FlyingGame"); }
    public void LoadSumo() { Time.timeScale = 1f; SceneManager.LoadScene("SumoGame"); }
    //public void QuitGame() { Application.Quit(); }
    public void QuitGame()
        {
            Time.timeScale = 1f;
        #if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;   // stops Play mode in Editor
        #else
            Application.Quit();                                // quits in a build
        #endif
        }

}
